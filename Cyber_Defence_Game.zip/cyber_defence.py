"""Cyber Defence: educational incident-response strategy game (standard library only)."""
import random
import tkinter as tk
from dataclasses import dataclass
from tkinter import ttk

@dataclass(frozen=True)
class Incident:
    name: str
    severity: int
    description: str
    best_control: str
    lesson: str

@dataclass(frozen=True)
class Defence:
    name: str
    power: int
    description: str

DEFENCES = [
    Defence("Email Filtering", 9, "Block suspicious email content and links."),
    Defence("Multi-Factor Authentication", 9, "Reduce account takeover risk."),
    Defence("Network Isolation", 10, "Contain a compromised device or network segment."),
    Defence("Patch Management", 8, "Reduce exposure to known vulnerabilities."),
]
INCIDENTS = [
    Incident("Phishing Email", 18, "Employees receive convincing credential-harvesting emails.", "Email Filtering", "Filtering helps, but staff awareness and verification matter too."),
    Incident("Credential Stuffing", 20, "Attackers try passwords leaked from unrelated services.", "Multi-Factor Authentication", "MFA helps prevent a stolen password from being enough."),
    Incident("Ransomware Alert", 25, "A workstation shows signs of ransomware execution.", "Network Isolation", "Containment limits spread; backups and recovery planning are also essential."),
    Incident("Unpatched Service", 19, "An exposed application has a known security flaw.", "Patch Management", "Prompt patching and inventory reduce exploitable exposure."),
    Incident("Suspicious Lateral Movement", 22, "Unusual connections suggest an intruder is moving between hosts.", "Network Isolation", "Segmenting and isolating affected systems can slow lateral movement."),
    Incident("Fake Login Portal", 17, "A fraudulent sign-in page is circulating among staff.", "Email Filtering", "Anti-phishing controls and domain verification help reduce exposure."),
]

class CyberGame:
    def __init__(self):
        self.integrity = 100
        self.deck = INCIDENTS.copy()
        random.shuffle(self.deck)
        self.round = 0
        self.current = None
        self.finished = False
        self.next_incident()

    def next_incident(self):
        if not self.deck:
            self.current = None
            self.finished = True
        else:
            self.current = self.deck.pop()
            self.round += 1

    def respond(self, defence):
        if self.finished or self.current is None:
            raise ValueError("No active incident")
        incident = self.current
        mitigation = defence.power + (incident.severity // 2 if defence.name == incident.best_control else 0)
        damage = max(0, incident.severity - mitigation)
        self.integrity = max(0, self.integrity - damage)
        outcome = (f"{defence.name} mitigated {incident.severity - damage} damage. "
                   f"Remaining damage: {damage}.\n\nLearning note: {incident.lesson}\n"
                   f"Recommended response: {incident.best_control}.")
        if self.integrity == 0:
            self.finished = True
            self.current = None
        else:
            self.next_incident()
        return outcome

class CyberDefenceApp:
    def __init__(self, root):
        self.root = root
        root.title("Cyber Defence | Incident Response")
        root.geometry("800x620")
        root.minsize(650, 550)
        root.configure(bg="#0e1726")
        self.game = CyberGame()
        self.title = tk.Label(root, text="CYBER DEFENCE", bg="#0e1726", fg="#5de2cf", font=("Arial", 25, "bold"))
        self.title.pack(pady=(24, 5))
        tk.Label(root, text="INCIDENT RESPONSE STRATEGY GAME", bg="#0e1726", fg="#d4e1ef", font=("Arial", 10)).pack()
        self.status = tk.Label(root, bg="#0e1726", fg="white", font=("Arial", 14, "bold"))
        self.status.pack(pady=20)
        self.card = tk.Frame(root, bg="#1c2b40", padx=24, pady=20)
        self.card.pack(fill="x", padx=35)
        self.incident_title = tk.Label(self.card, bg="#1c2b40", fg="#ffcf75", font=("Arial", 18, "bold"))
        self.incident_title.pack(anchor="w")
        self.description = tk.Label(self.card, bg="#1c2b40", fg="white", font=("Arial", 11), wraplength=680, justify="left")
        self.description.pack(anchor="w", pady=(10, 0))
        tk.Label(root, text="CHOOSE YOUR RESPONSE", bg="#0e1726", fg="#d4e1ef", font=("Arial", 11, "bold")).pack(pady=(18, 8))
        self.buttons = []
        actions = tk.Frame(root, bg="#0e1726")
        actions.pack(fill="x", padx=35)
        for i, defence in enumerate(DEFENCES):
            btn = tk.Button(actions, text=defence.name, command=lambda d=defence: self.choose(d),
                            bg="#236b83", fg="white", activebackground="#36a4a5", relief="flat", pady=12)
            btn.grid(row=i//2, column=i%2, sticky="ew", padx=5, pady=5)
            self.buttons.append(btn)
        actions.grid_columnconfigure(0, weight=1)
        actions.grid_columnconfigure(1, weight=1)
        self.feedback = tk.Label(root, bg="#0e1726", fg="#c9d8e6", wraplength=710, justify="left", font=("Arial", 10))
        self.feedback.pack(padx=35, pady=15)
        tk.Button(root, text="Start / Restart", command=self.restart, bg="#5de2cf", fg="#102337", relief="flat", padx=22, pady=9).pack(side="bottom", pady=18)
        self.refresh()

    def choose(self, defence):
        result = self.game.respond(defence)
        self.feedback.config(text=result)
        self.refresh()

    def restart(self):
        self.game = CyberGame()
        self.feedback.config(text="Choose the most appropriate defence for each incident.")
        self.refresh()

    def refresh(self):
        self.status.config(text=f"System integrity: {self.game.integrity}%    |    Round: {self.game.round}/{len(INCIDENTS)}")
        if self.game.finished:
            win = self.game.integrity > 0
            self.incident_title.config(text="MISSION COMPLETE" if win else "SYSTEM COMPROMISED")
            self.description.config(text="You defended the organisation!" if win else "Integrity reached zero. Restart to try again.")
        else:
            incident = self.game.current
            self.incident_title.config(text=f"{incident.name}  •  Severity {incident.severity}")
            self.description.config(text=incident.description)
        for button in self.buttons:
            button.config(state="disabled" if self.game.finished else "normal")

if __name__ == "__main__":
    window = tk.Tk()
    CyberDefenceApp(window)
    window.mainloop()
