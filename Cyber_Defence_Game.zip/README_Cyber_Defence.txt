Cyber Defence - Incident Response Strategy Game

Run: python cyber_defence.py
Requires Python 3.10+ and Tkinter.
This is a new educational redesign inspired by the supplied Programming 2 card game.
